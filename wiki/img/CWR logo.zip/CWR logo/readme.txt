Logo created by Daniel van Aswegen and Hannes Dempewolf
 - daniel.vanaswegen@gmail.com
 - hdempewolf@gmail.com